# Skill Node Design Grill

This directory is a design engagement archive for the Fork/AIG work. It preserves the historical grill material while adding a compact traceability layer for future design and delivery cycles.

## Current state

- Current index: [state.md](state.md)
- Formal design sources in this archive: [CONSENSUS.md](CONSENSUS.md), [CONTEXT.md](CONTEXT.md), and [ADR-0043](docs/adr/0043-aig-native-fork-overlay-and-guided-remediation.md). Memory Hint receipts follow CONSENSUS `memory-disposition-receipt/Q190–Q216`. The default Memory Agent follows CONSENSUS `default-memory-agent/Q217–Q235`.
- Current implementation gate in the archived design: Q165-A remains closed; a plan or historical test is not delivery authorization.
- Current grill: [cycle 004](cycles/004-role-tool-review.md) reviews Builder, Critic, Refiner, and Reader on the local main branches. Q236 is deferred to feature-branch integration review.
- Current implementation evidence: [`DLV-002`](implementation/traceability.md) records the default Memory Agent delivery. The role-tool review has no product delivery.

## Navigate

| Area | Covers |
|---|---|
| [cycles/](cycles/001-traceability-bootstrap.md) | Append-only grill cycles: frontier, answers, decisions, and closure. |
| [implementation/](implementation/traceability.md) | Decision-to-delivery evidence: branch, worktree, SHA, status, and validation. |
| [operations/](operations/worktrees.md) | Registered branch and worktree lifecycle. |
| [registers/](registers/open-questions.md) | Live open questions, risks, and deferred directions. |
| [review/](review/main-branches-20261014.md) | Current main-branch assessment, with the earlier feature-branch review retained separately. |
| [impl/](impl/) | Historical implementation plans, verification evidence, tickets, and handoffs. |
| [eval/](eval/) | Historical evaluation plans and evidence. |
| [round-*-*.md](round-29-questions.md) | Source questions, answers, briefs, and raw records from prior grills. |

## Record discipline

The traceability layer is operational evidence, not a replacement for formal requirements. A confirmed term, contract, or irreversible decision belongs in the host repository's authoritative source; each cycle links to it. Closed cycle records preserve what was decided at the time. `state.md` is the only mutable convenience index.

Use the project-local `grill-with-traceability` skill for future cycles.
